# Circular — Singapore Schema Mapping (Stage 2)

> Stage 2 deliverable per MARKET_EXPANSION_CHECKLIST.md.
> Maps every HK reference schema field to its SG equivalent.
> Gate document — Stage 3 (scraper build) cannot start until this is committed.
>
> Mapping types:
> - `direct`      — exact 1:1 mapping
> - `derived`     — computable from other fields (formula in Notes)
> - `renamed`     — same data, different field name
> - `unavailable` — store as `null`, reason in Notes
> - `new`         — SG-specific field not in HK reference

---

## File layout

All SG data lives under `data/sg/`:

```
data/sg/
├── universe.json
├── di_index.json
├── ca_index.json
├── last_run.json
├── di/{code}.json            ← Section 1 — Disclosure of Interests
├── corp_actions/{code}.json  ← Section 2 — Corporate Actions
└── cap_market/{code}.json    ← Section 3 — Capital Market
```

Stock code key for SG: **SGX trading code** (e.g. `D05` for DBS, `Z74` for Singtel,
`C6L` for SIA). No zero-padding — SGX codes are alphanumeric and case-sensitive.

A `security_type` field appears at the root of every section JSON for SG to
distinguish ordinary shares from REIT/Business Trust units. UI labels swap
"shares" ↔ "units" off this field.

---

## Section 1 — Disclosure of Interests

`data/sg/di/{code}.json`

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `code` | direct | SGX trading code | e.g. `D05`. Used as the file key. |
| `name` | direct | Issuer name from SGXNET payload | English only. No translation needed. |
| `last_updated` | direct | Scrape timestamp | ISO 8601 UTC. |
| `security_type` | new | Derived from SGX reference data | `"share"` or `"unit"`. Required at root. |
| `shareholders[].name` | direct | MAS Form 1/3 § "Name of Substantial Shareholder" | Normalise whitespace + casing. |
| `shareholders[].type` | derived | Inferred from form fields | `Individual` if NRIC present, `Corporate` if UEN present, `Fund` if registered as fund manager. |
| `shareholders[].long_position_shares` | direct | Form 1 § "Number of voting shares" (long) | Aggregate direct + deemed. |
| `shareholders[].long_position_pct` | direct | Form 1 § "% of issued voting shares" | Stored at filing time. |
| `shareholders[].short_position_shares` | unavailable | — | Singapore DI does not require granular short positions at the substantial-shareholder level. Store `null`. Cross-reference Section 3 (CM) for aggregate short data. |
| `shareholders[].short_position_pct` | unavailable | — | Same as above. `null`. |
| `shareholders[].deemed_interest` | direct | Form 1 § "Deemed interest" | Boolean + linked entity name where present. |
| `shareholders[].filing_date` | direct | SGXNET announcement timestamp | ISO 8601. |
| `shareholders[].filing_form_type` | renamed | MAS form number | HK: "Form 3A/3B/3C". SG: "Form 1" (initial), "Form 3" (changes), "Form 4" (cessation). Store the raw form name. |
| `shareholders[].event_type` | derived | Inferred from form_type + delta | `Initial` if Form 1, `Increase` / `Decrease` if Form 3 with directional delta, `Ceased` if Form 4. |
| `shareholders[].threshold_crossed` | derived | Computed from `long_position_pct` history | Whole-percentage crossings — same logic as HK. |
| `shareholders[].role` | new | Form field § "Capacity of the substantial shareholder" | `substantial_shareholder` / `director` / `ceo`. Critical for SG — directors' dealings share the same filing pipeline as DI changes. |
| `shareholders[].notes` | direct | Form free-text remarks | Truncate to 500 chars. |
| `shareholders[].filing_url` | direct | PDF attachment URL from SGXNET JSON | `links.sgx.com/FileOpen/...` |
| `history[]` | direct | Array of all events trimmed to 52 weeks | Same trim logic as HK. |
| `name_translated` | unavailable | — | Always `false` for SG. Field kept for cross-market schema consistency. |

**Filing-form catalogue (SG):**

| MAS form | Triggered by | Maps to `event_type` |
|---|---|---|
| Form 1 | New substantial shareholder (crosses 5%) | `Initial` |
| Form 3 | Change in interest of existing substantial shareholder | `Increase` or `Decrease` (signed) |
| Form 4 | Ceases to be a substantial shareholder (falls below 5%) | `Ceased` |

---

## Section 2 — Corporate Actions

`data/sg/corp_actions/{code}.json`

### 2a. Mandate

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `mandate.pct` | direct | AGM circular § "Maximum % of issued shares" | Default cap is 10% under SGX Rule 882. |
| `mandate.shares_authorised` | direct | AGM circular § "Maximum number of shares" | At resolution date. |
| `mandate.shares_used_ytd` | derived | Sum of `daily_returns[].shares_repurchased` since mandate start | Computed at write time. |
| `mandate.pct_used_of_issued` | derived | `shares_used_ytd / issued_capital × 100` | Same formula as HK. |
| `mandate.pct_used_of_mandate` | derived | `shares_used_ytd / shares_authorised × 100` | Same formula as HK. |
| `mandate.pct_remaining_of_issued` | derived | `mandate.pct − pct_used_of_issued` | Same formula as HK. |
| `mandate.pct_remaining_of_mandate` | derived | `100 − pct_used_of_mandate` | Same formula as HK. |
| `mandate.agm_date` | direct | AGM circular date | ISO 8601. |
| `mandate.expiry_note` | direct | Circular text | Standard SG language: "earlier of next AGM or 12 months from resolution". |
| `mandate.circular_url` | direct | SGXNET PDF URL | `links.sgx.com/...` |
| `mandate.renewal_probability` | derived | 4-signal heuristic (same as HK) | Re-validate weights against SG historical data post-launch. |

### 2b. Summary

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `summary.ytd_shares` | derived | Sum of `daily_returns[].shares_repurchased` for current FY | |
| `summary.ytd_consideration_hkd` | renamed → `summary.ytd_consideration_sgd` | Sum of `daily_returns[].consideration_sgd` | **Currency change.** All amounts in SGD for SG; emit `currency: "SGD"` at root. |
| `summary.ytd_pct_of_issued` | derived | Same formula | |
| `summary.ytd_pct_of_float` | derived | `ytd_shares / float_shares × 100` | Needs free-float input — see open item below. |
| `summary.ytd_vwap_sgd` | derived | `ytd_consideration_sgd / ytd_shares` | Renamed for SG currency. |
| `summary.current_price_sgd` | direct | yfinance `{CODE}.SI` close | Refresh nightly. |
| `summary.vwap_underwater` | derived | `current_price < ytd_vwap` | |
| `summary.still_active` | derived | Any `daily_returns[]` entry in last 30 days | |
| `summary.buyback_yield_annualised` | derived | Same formula as HK | |
| `summary.dividend_yield` | direct | yfinance | |
| `summary.total_return_yield` | derived | `buyback_yield + dividend_yield` | |
| `summary.net_capital_return_ytd_sgd` | derived | `ytd_consideration − ytd_issuances_proceeds` | |
| `summary.programme_active` | derived | `still_active && mandate.pct_remaining_of_mandate > 0` | |

### 2c. Buyback returns — **STRUCTURAL DIFFERENCE FROM HK**

HK files **monthly** returns. SG files **daily** under Appendix 8D — one
filing per buyback day. Therefore the array name and per-entry shape change:

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `monthly_returns[]` | renamed → `daily_returns[]` | One entry per SGXNET Appendix 8D filing | Richer than HK. Roll-up to monthly happens client-side. |
| `monthly_returns[].period` | renamed → `daily_returns[].date` | Trade date from Appendix 8D | ISO 8601 date, not month. |
| `monthly_returns[].filing_date` | direct | SGXNET announcement timestamp | |
| `monthly_returns[].filing_url` | direct | PDF URL | |
| `monthly_returns[].shares_repurchased` | direct | Appendix 8D § "Number of shares purchased" | |
| `monthly_returns[].consideration_hkd` | renamed → `consideration_sgd` | Appendix 8D § "Total consideration" | SGD. |
| `monthly_returns[].price_high` | direct | Appendix 8D § "Highest price per share" | |
| `monthly_returns[].price_low` | direct | Appendix 8D § "Lowest price per share" | |
| `monthly_returns[].monthly_traded_volume` | renamed → `daily_traded_volume` | Day's total traded volume | From yfinance daily volume on `date`. |
| `monthly_returns[].cum_ytd_pct_of_issued` | direct | Appendix 8D § "Cumulative % of issued shares" | Filed by issuer in the form itself. |
| `monthly_returns[].days_active` | unavailable | — | N/A for daily filings. Drop the field. |
| `monthly_returns[].is_blackout` | derived | `date` within ±30 days of `results_dates[]` | Same logic as HK. |
| `daily_returns[].on_market_shares` | new | Appendix 8D § "Number purchased on-market" | SG-specific granularity. |
| `daily_returns[].off_market_shares` | new | Appendix 8D § "Number purchased off-market" | SG-specific granularity. |

### 2d. Issuances

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `issuances[].date` | direct | SGXNET announcement date | |
| `issuances[].type` | renamed | SGXNET headline category | SG types: `placement`, `rights_issue`, `bonus_issue`, `scrip_dividend`, `convertible_bond`. Note `scrip_dividend` is SG-specific. |
| `issuances[].label` | direct | Announcement title | |
| `issuances[].shares` | direct | PDF § "Number of new shares" | |
| `issuances[].consideration_sgd` | renamed | PDF § "Gross proceeds" | SGD. |
| `issuances[].price_per_share` | direct | PDF § "Issue price" | |
| `issuances[].filing_url` | direct | PDF URL | |

### 2e. Results dates

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `results_dates[].type` | direct | SGXNET form metadata | SG types: `interim` (half-year), `annual` (full-year), `q1` / `q3` (only for issuers that report quarterly — voluntary in SG). |
| `results_dates[].date` | direct | Announcement date | |
| `results_dates[].filing_url` | direct | PDF URL | Null if forward-looking estimate. |

### 2f. Root-level

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `free_float_pct` | direct | Annual report § "Public float" | Manual seed file `data/sg/free_float.json` for top 50 names initially. |
| `consistency_score` | derived | Same 1–5 logic as HK | Re-validate thresholds against SG buyback patterns post-launch. |
| `signal` | derived | Same logic as HK | |
| `security_type` | new | SGX reference data | `"share"` or `"unit"`. |
| `currency` | new | Always `"SGD"` | Root-level constant for SG. Frontend uses this to render currency labels. |

---

## Section 3 — Capital Market

`data/sg/cap_market/{code}.json`

| HK reference field | Mapping | SG source field | Notes |
|---|---|---|---|
| `code` | direct | SGX trading code | |
| `security_type` | new | From universe | Same field as other sections. |
| `last_updated` | direct | Scrape timestamp | |
| `short_history[].date` | direct | SGX Daily Short Sell Report `Date` column | |
| `short_history[].volume` | direct | Report `Short Sale Volume` column | |
| `short_history[].value_sgd` | renamed | Report `Short Sale Value` column | SGD instead of HKD. |
| `short_history[].pct_of_turnover` | direct | Report `Short Sale Volume Ratio` column | Already provided in the CSV — no client-side division needed. |
| `connect_flows[]` | unavailable | — | **N/A for SG.** No mainland-China connect equivalent. Always `null`. |
| `daily_turnover[].date` | direct | yfinance daily | |
| `daily_turnover[].volume` | direct | yfinance | |
| `daily_turnover[].value_sgd` | derived | `volume × close_price` | yfinance does not provide turnover value directly. |
| `short_selling_eligible` | direct | CDP Securities Borrowing & Lending pool list | Boolean. Refresh weekly. |
| `currency` | new | Always `"SGD"` | |

---

## Index files

### `data/sg/di_index.json`

Inverted index: shareholder name → list of stock codes. Same shape as HK.
Name normalisation: SG-only — strip "(Pte) Ltd" / "Limited" / "Pte. Ltd."
suffixes when matching to surface BlackRock entries that may be filed
under different legal-entity names.

### `data/sg/ca_index.json`

League table for the Corporate Actions section. Same shape as HK, with
HKD→SGD field renames. Add `security_type` at the entry level so the UI
can label REIT entries differently in the league table.

### `data/sg/last_run.json`

Same shape as HK. Three sub-keys per section: `di`, `corp_actions`,
`cap_market`. Each carries `last_scrape`, `stocks_touched`, `errors[]`.

---

## Open items carried into Stage 3

1. **api.sgx.com category codes.** Drafted as constants with placeholder
   values in `config/sgx_categories.py`. Real codes must be confirmed via
   browser dev-tools inspection before the first scraper run — the
   placeholders are explicitly marked TODO with verification instructions.

2. **Free-float seed file.** Need `data/sg/free_float.json` populated for
   the top ~50 SG names before launch. Source: company annual reports
   (corporate governance section). Manual quarterly refresh.

3. **REIT/Trust universe flag.** During `build_universe.py --market sg`,
   tag each ticker with `security_type` from SGX reference data so the
   downstream scrapers can stamp it onto every output file. Mainboard
   REITs and Business Trusts are distinguishable by SGX sector / asset
   type classification.

4. **PDF parsing template for MAS Form 1/3.** Build one shared parser
   (since the layout is standardised by MAS). Budget 5% failure on older
   scanned filings — store filing metadata + raw PDF URL even on parse
   failure.

5. **Currency in cross-market views.** When the frontend cross-references
   data between HK and SG (e.g. a shareholder appearing in both markets),
   it must read the root-level `currency` field per file rather than
   assuming a global currency. This is the main schema-level change to
   the cross-reference timeline.

---

**Stage 2 sign-off:** _date when this document is committed to the repo._
