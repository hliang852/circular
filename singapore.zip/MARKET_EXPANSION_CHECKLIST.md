# Circular — Market Expansion Checklist
## Master Due-Diligence Reference for Adding a New Market

> This document is the canonical due-diligence reference for adding a new market
> to Circular. It is referenced from CIRCULAR_WORKFLOW_MAIN.md and complements
> it: the workflow doc defines the *system*, this doc defines the *gate criteria*
> a market must clear before any code is written.
>
> Read alongside:
> - CIRCULAR_WORKFLOW_MAIN.md — the canonical workflow + system architecture
> - CONTEXT.md — design rationale for the HK reference market
> - ENGINEER_HANDOFF.md — module-level build detail
>
> Hong Kong is the reference implementation. All new markets are evaluated
> by mapping their public data sources back to the HK schema, section by section
> (DI / Corporate Actions / Capital Market). A market can launch sections
> independently — DI live while CA is still in beta, for example.

---

## How to Use This Document

```
+--------------------------------------------------------------------+
|  WORKFLOW                                                          |
|                                                                    |
|  1. Open a new "Market Entry" section at the bottom of this file.  |
|  2. Work Stage 1 -> Stage 7 IN ORDER. Each stage has a gate.       |
|     Do NOT proceed to the next stage until the current gate        |
|     passes.                                                        |
|  3. Each section (DI / CA / CM) is evaluated SEPARATELY at every   |
|     stage. A market may pass Stage 1 for DI but fail for CM.       |
|  4. Update markets.json status as each section progresses:         |
|     planned -> beta (Stage 6 done) -> live (Stage 7 done)          |
|  5. Commit this file whenever a gate is passed. The git history    |
|     becomes the audit trail for "why is X in this state?"          |
+--------------------------------------------------------------------+
```

Every stage below has three parts:

- **Gate criteria** — what must be true to pass the stage
- **Sub-checks** — concrete items to verify
- **Exit condition** — the explicit "you are done" trigger

---

## The Seven Stages

```
   STAGE 1               STAGE 2              STAGE 3
   Market                Data                 Scraper
   Qualification   -->   Exploration    -->   Build
   Gate                  (schema map)         (Python)
                                                |
                                                v
   STAGE 7               STAGE 6              STAGE 4
   Disclaimer            Implement     <--    Data
   + Compliance    <--   (HTML/JSON)          Validation
   Review                                     (5-10 stocks)
                                                |
                                                v
                         STAGE 5
                         Prototype
                         (frontend with
                         real data)
```

A market can be in different stages for different sections at the same time.
Track each section in its own row in the market entry below.

---

### Stage 1 — Market Qualification Gate

The hardest gate. If this fails, do not invest engineering time. Most
candidate markets fail Stage 1 for at least one section.

**Gate criteria.** All four must be true *for the section being qualified*:

1. **Public accessibility.** Data is reachable without a paid licence,
   institutional account, or institutional VPN.
2. **Machine-readability.** Data is in HTML, JSON, XML/XBRL, CSV, or PDF
   (not behind a CAPTCHA-by-default flow, not Flash, not authenticated
   WebSocket-only).
3. **Legal to scrape.** Public exchange / regulator data with no Terms of
   Service clause explicitly forbidding automated retrieval. Where a ToS
   is ambiguous, document it and flag for Stage 7 review — do not skip.
4. **52-week feasibility.** A full 52-week backfill is achievable in a
   single overnight GitHub Actions run (6h max) at a polite rate limit
   (1.5-3s between requests).

**Sub-checks per section:**

```
DI section
- [ ] Substantial-shareholder threshold defined (typically 5%)
- [ ] Single public source identified for ALL DI filings in the market
- [ ] Filing format known (HTML / PDF / XBRL)
- [ ] Estimate of filings per year established (for backfill scoping)
- [ ] Translation requirement flagged Y/N

CA section
- [ ] Buyback monthly/daily return format identified
- [ ] Repurchase mandate circular source identified
- [ ] Placing / rights / CB filing categories enumerated
- [ ] Results announcement source identified
- [ ] Director-dealings source identified (may share DI pipeline)

CM section
- [ ] Daily short-sell report source identified (or N/A)
- [ ] Daily turnover source identified
- [ ] Cross-border flows source identified (Connect-equivalent, may be N/A)
- [ ] Short-selling eligibility list source identified
```

**Exit condition.** A completed Stage 1 entry for that section in the
"Market Entries" block at the bottom of this file, with every sub-check
ticked or marked N/A. *Only then* proceed to Stage 2.

---

### Stage 2 — Data Exploration

Schema mapping. The goal is to map every field in the HK reference schema
to the equivalent field in the new market, identify gaps, and decide what
to do with them (null, derived, or new-field).

**Gate criteria.**

1. Schema map complete for every field in the HK reference schema for
   that section (see "Schema Mapping Template" further down this file).
2. Every gap field categorised as one of:
   - `direct`     — exact 1:1 mapping
   - `derived`    — computable from other fields (document the formula)
   - `renamed`    — same data, different name (document the alias)
   - `unavailable` — store as `null`, document the reason
   - `new`        — market-specific field not in HK reference (document the rationale)
3. Lookback window confirmed (default: 52 weeks). Note exceptions.
4. Scrape frequency confirmed (default: nightly Mon-Fri + Sunday full).
5. Translation layer scope defined if applicable. List the fields that
   need translation, name normalisation rules, and English-source fallback.

**Sub-checks:**

```
- [ ] Schema mapping table filled in (all fields, all sections)
- [ ] Sample of 5 real filings inspected (not just rule books)
- [ ] PDF parsing library validated against 3 sample PDFs
- [ ] Translation layer scope written down (or marked N/A)
- [ ] Universe filter rule defined (e.g. > $100M USD mkt cap)
- [ ] Universe size estimated (so Stage 4 has a realistic target)
- [ ] Legal/ToS notes captured for Stage 7
```

**Exit condition.** Schema map committed. No remaining "unknown" cells.

---

### Stage 3 — Scraper Build (Python)

Pure engineering. Fork `BaseScraper`, implement the market subclass per
section, hook up GitHub Actions inputs.

**Gate criteria.**

1. One scraper file per section (or one file with clean separation):
   `scripts/scrape_di.py`, `scripts/scrape_corp_actions.py`,
   `scripts/scrape_cap_market.py`.
2. Each scraper accepts a `--market` flag (`hk` / `sg` / `jp` / `all`) and
   a `--mode` flag (`incremental` / `full`).
3. Output path conforms to the namespace: `data/{market}/{section}/{code}.json`.
4. 52-week trim applied at scrape time (not at read time).
5. Polite rate limit implemented (1.5-3s randomised; exponential backoff on 429).
6. Failures logged to `data/{market}/last_run.json` — never silently dropped.
7. Translation layer (where required) implemented as Step 2a of the pipeline,
   with `name_translated: true` flag written to output records.
8. `workflow_dispatch` inputs added to the relevant `.github/workflows/*.yml`.

**Sub-checks:**

```
- [ ] One scraper per section, no cross-coupling
- [ ] Market-specific quirks isolated in a single class/module
- [ ] Translation layer (if required) gated on field-level flag
- [ ] 52-week trim implemented at write time
- [ ] Rate limit + backoff implemented
- [ ] last_run.json updated per run (success, errors, stocks touched)
- [ ] workflow_dispatch tested locally with `act` or in a draft PR run
```

**Exit condition.** All three scraper scripts pass `python -m py_compile`
*and* run end-to-end on a 5-stock sample without errors.

---

### Stage 4 — Data Validation

The real "do we trust this?" gate. Run the scrapers, eyeball the output,
cross-check against a known source.

**Gate criteria.**

1. Sample of 5-10 representative stocks scraped successfully.
   "Representative" means: 2 large caps, 2 mid caps, 1 small cap, 1 REIT
   if applicable, 1 stock with known recent corporate activity.
2. PDF extraction success rate >= 90% on the sample. Image-based PDFs are
   acceptable failures provided the *filing metadata* is still stored.
3. JSON schema validates for every output file (use `jsonschema` against a
   committed schema file).
4. Cross-check: for at least 2 stocks, manually verify the output JSON
   against the source filing. Note any discrepancies in this checklist.
5. Translated names (if applicable) reviewed by a native speaker or
   verified against a second source for at least 5 entities.

**Sub-checks:**

```
- [ ] 5-10 stock sample run completed
- [ ] Schema validation passes for all sample outputs
- [ ] PDF parse failure rate < 10%
- [ ] 2 stocks manually cross-checked end-to-end
- [ ] Translated entity names spot-checked (or N/A)
- [ ] last_run.json shows clean run (or documented failure modes)
- [ ] File size sanity: average per-stock JSON < 20 KB
```

**Exit condition.** Sample data committed to `data/{market}/` and reviewed.
Only proceed to Stage 5 when the output is *trusted*.

---

### Stage 5 — Prototype (Frontend)

Wire the validated Stage 4 data into the existing HK frontend with the
market namespace. NO mock data at this stage — the prototype is built
against real, scraped JSON.

**Gate criteria.**

1. Existing HK frontend components render correctly with the new market's
   JSON without per-stock special-casing.
2. All three section tabs work for the sample stocks. The cross-reference
   timeline pulls events from all three sections.
3. Market selector on the landing page surfaces the new market with the
   correct `beta` badge.
4. REIT / Business Trust handling (where applicable) renders "units" not
   "shares" correctly via `security_type` field.

**Sub-checks:**

```
- [ ] Frontend renders DI section without errors
- [ ] Frontend renders Corporate Actions section without errors
- [ ] Frontend renders Capital Market section without errors
- [ ] Cross-reference timeline merges events across sections correctly
- [ ] Market selector + freshness badge wired up
- [ ] Mobile layout tested
```

**Exit condition.** A non-technical reviewer can open the prototype, pick
a stock, and find the same information they would from the source filing.

---

### Stage 6 — Implement (HTML / JSON)

Live wiring. The frontend now fetches from production paths
(`data/{market}/{section}/{code}.json`) and the market is published in
`markets.json` with `status: "beta"`.

**Gate criteria.**

1. `markets.json` updated with full section block for the new market.
2. All fetch paths use the canonical `data/{market}/{section}/{code}.json`
   pattern.
3. Indexes (`di_index.json`, `ca_index.json`) generated successfully.
4. GitHub Actions workflows live + scheduled (not draft).
5. At least one full nightly run has completed end-to-end and committed
   data without manual intervention.

**Sub-checks:**

```
- [ ] markets.json includes the new market with all three sections
- [ ] All status flags accurate (live / beta / planned)
- [ ] Indexes built and committed
- [ ] Nightly workflow ran clean for 1 full cycle
- [ ] No hardcoded sample data left in frontend
```

**Exit condition.** The new market section is publicly visible at
`circular.github.io` with `status: "beta"`.

---

### Stage 7 — Disclaimer + Compliance Review

The legal / publication gate. Promotes section from `beta` to `live`.

**Gate criteria.**

1. "Not investment advice" label visible on every page of the new market.
2. ToS / legal notes from Stage 1 and Stage 2 re-reviewed. No outstanding
   concerns.
3. Source attribution visible per data point (e.g. "Source: SGXNET",
   "Source: EDINET").
4. Translation provenance disclosed where applicable ("Names translated
   from Japanese — verify against original filing").
5. Rate-limit + back-off behaviour reviewed once more — no signs of
   bot-detection escalation in `last_run.json` over the beta period.
6. Beta period of at least 14 calendar days completed with clean nightly
   runs.

**Sub-checks:**

```
- [ ] Disclaimer label present on all pages
- [ ] Source attribution rendered per data card
- [ ] ToS review passed (or counsel signed off if client-facing)
- [ ] Translation provenance disclosed (or N/A)
- [ ] 14-day beta run clean in last_run.json
- [ ] markets.json status updated: beta -> live
```

**Exit condition.** Section status in `markets.json` flipped to `live`.
The new market is now part of the supported set.

---

## Schema Mapping Template

Use this table once per section, per market, during Stage 2. The HK column
is fixed (reference). Fill in the new-market column from real sample
filings, not from rule books.

### DI section template

```
HK REFERENCE FIELD              MAPPING TYPE     NEW-MARKET SOURCE FIELD
------------------------------  ---------------  ------------------------------
shareholder_name                direct/translate ...
shareholder_type                direct           ...
long_position_shares            direct           ...
long_position_pct               direct           ...
short_position_shares           direct/null      ...
short_position_pct              direct/null      ...
deemed_interest                 direct           ...
filing_date                     direct           ...
filing_form_type                renamed          ...
event_type (incr/decr/cease)    direct/derived   ...
threshold_crossed               direct/derived   ...
notes                           direct           ...
name_translated                 new/N-A          (true|false)
```

### CA section template

```
HK REFERENCE FIELD              MAPPING TYPE     NEW-MARKET SOURCE FIELD
------------------------------  ---------------  ------------------------------
mandate.pct                     direct           ...
mandate.shares_authorised       direct           ...
mandate.agm_date                direct           ...
mandate.expiry_note             direct           ...
mandate.circular_url            direct           ...
summary.ytd_shares              direct/derived   ...
summary.ytd_consideration       direct/derived   ...
summary.ytd_vwap                direct/derived   ...
monthly_returns[]               direct/renamed   (SG: daily_returns[])
monthly_returns.shares          direct           ...
monthly_returns.consideration   direct           ...
monthly_returns.price_high      direct           ...
monthly_returns.price_low       direct           ...
monthly_returns.filing_url      direct           ...
issuances[].type                direct           ...
issuances[].shares              direct           ...
issuances[].consideration       direct           ...
issuances[].filing_url          direct           ...
results_dates[].type            direct           ...
results_dates[].date            direct           ...
security_type                   new              (share | unit)
```

### CM section template

```
HK REFERENCE FIELD              MAPPING TYPE     NEW-MARKET SOURCE FIELD
------------------------------  ---------------  ------------------------------
short_history[].date            direct           ...
short_history[].volume          direct           ...
short_history[].value           direct           ...
short_history[].pct_of_turnover direct/derived   ...
connect_flows[]                 direct/null      (N/A for SG)
daily_turnover[]                direct           ...
short_selling_eligible          direct           ...
```

---

## Market Entries

Each market gets its own block below. Stages are filled in as completed.
Sister markets (HK done, SG in progress, JP planned) all live here.

---

### Hong Kong (HK) — Reference Market

```
Status:        LIVE across all three sections
Universe:      ~700 stocks, > $100M USD mkt cap
Lookback:      52 weeks (incremental nightly)
Sections:      DI live | CA live | CM live
```

Hong Kong is the reference implementation. Its design rationale lives in
CONTEXT.md and its module-level build detail in ENGINEER_HANDOFF.md. No
stage entries reproduced here — HK predates this checklist.

Key reference characteristics for comparison:
- DI portal is old ASP.NET WebForms (VIEWSTATE token dance required)
- CA filings on HKEXnews use a JSON API (no tokens)
- CCASS provides custodian-level shareholding below the 5% DI threshold
- Stock Connect Northbound flows provide mainland-China inflow data
- All filings in English

---

### Singapore (SG) — In Progress

```
Status:        Stage 1 complete | Stages 2-7 pending
Universe:      ~150-220 stocks expected (> $100M USD mkt cap filter,
               from ~640 Mainboard + ~215 Catalist universe)
Lookback:      52 weeks (incremental nightly)
Sections:      DI Stage 1 OK | CA Stage 1 OK | CM Stage 1 OK
```

#### Stage 1 — Market Qualification Gate: COMPLETE

**Headline finding.** Singapore is structurally simpler than HK. Every
filing — substantial-shareholder disclosures, daily buybacks, placings,
rights issues, CBs, results, director dealings — flows through a single
channel called SGXNET, exposed publicly at
`https://api.sgx.com/announcements/v1.0/`. There is no equivalent to HK's
split between the HKEX DI portal and HKEXnews. Since November 2012,
substantial shareholders no longer report separately to SGX — they notify
the company, which then disseminates via SGXNET.

**Universe characteristics.**

- ~640 Mainboard + ~215 Catalist listings = ~850 securities
- After > $100M USD market-cap filter: expect ~150-220 names
- REITs and Business Trusts are a material share — use "units" not "shares"
- Universe build path: SGX securities reference data (no auth) for ticker
  list, then yfinance with `.SI` suffix for market cap

**Section-by-section qualification:**

```
+--------------------------------------------------------------------+
|  DI SECTION                                                         |
|                                                                     |
|  Public accessibility:  YES — api.sgx.com is open, no auth         |
|  Machine readability:   YES — JSON API + PDF attachments           |
|  Legal to scrape:       LIKELY YES — flag for Stage 7 ToS review   |
|  52-week feasibility:   YES — ~150 stocks x ~15 events/year        |
|                                                                     |
|  Threshold:             5% (Securities and Futures Act)            |
|  Single source:         SGXNET via api.sgx.com (category: DOI)     |
|  Filing format:         JSON metadata + PDF attachment (MAS Form   |
|                         1/3, standardised layout)                  |
|  Translation needed:    NO (English filings only)                  |
|                                                                     |
|  Sub-checks: [x] threshold [x] source [x] format [x] backfill      |
|              [x] translation flag                                  |
+--------------------------------------------------------------------+

+--------------------------------------------------------------------+
|  CA SECTION                                                         |
|                                                                     |
|  Public accessibility:  YES                                         |
|  Machine readability:   YES — same JSON API + PDF attachments       |
|  Legal to scrape:       LIKELY YES — Stage 7 ToS review             |
|  52-week feasibility:   YES                                         |
|                                                                     |
|  Buyback format:        DAILY filing (Appendix 8D), one filing per |
|                         buyback day. RICHER than HK's monthly.     |
|  Mandate source:        AGM circular via SGXNET (April-June heavy) |
|  Placings/rights:       SGXNET headline categories                 |
|  Results announcements: SGXNET "Financial Statements" category     |
|  Director dealings:     Same DOI announcement stream (free with DI |
|                         scraper) — distinguish by `role` field     |
|                                                                     |
|  Sub-checks: [x] buyback [x] mandate [x] placings [x] results      |
|              [x] director dealings                                 |
+--------------------------------------------------------------------+

+--------------------------------------------------------------------+
|  CM SECTION                                                         |
|                                                                     |
|  Public accessibility:  YES                                         |
|  Machine readability:   YES — CSV downloads                         |
|  Legal to scrape:       YES                                         |
|  52-week feasibility:   YES                                         |
|                                                                     |
|  Daily short sell:      sgx.com/research-education/securities      |
|                         downloadable file per trading day          |
|  Daily turnover:        yfinance (with .SI suffix) as fallback;    |
|                         SGX has a paid delayed REST feed           |
|  Connect flows:         N/A — Singapore has no mainland-China      |
|                         connect equivalent. Store as null.         |
|  Short eligibility:     CDP Securities Borrowing & Lending pool    |
|                         list, refreshed weekly                     |
|                                                                     |
|  Sub-checks: [x] short report [x] turnover [N/A] connect           |
|              [x] eligibility                                       |
+--------------------------------------------------------------------+
```

**Reference data sources (locked for Stage 2 schema mapping):**

```
Source                                 Section  Endpoint / Method
-------------------------------------  -------  ------------------------------
SGXNET announcements API               DI/CA    GET api.sgx.com/announcements/
                                                v1.0/?periodstart=...
                                                &periodend=...&cat=GE
MAS Form 1 / Form 3 PDF attachments    DI       links.sgx.com/FileOpen/...
                                                (URL inside announcement JSON)
Daily Share Buy-Back Notice (App 8D)   CA       SGXNET category "Share Buy Back"
Repurchase Mandate Circulars           CA       SGXNET AGM circulars filter
Placings / Rights / Bonus / CB         CA       SGXNET headline categories
Financial Results                      CA       SGXNET "Financial Statements"
SGX Daily Short Sell Report            CM       sgx.com/research-education/
                                                securities (CSV per day)
SGX Monthly Market Statistics          CM       sgx.com/research-education/
                                                historical-data/market-statistics
Securities Borrowing & Lending pool    CM       sgx.com/securities
Daily OHLC / volume (fallback)         CM       yfinance ({CODE}.SI)
```

**Key differences vs HK to bake into Stage 2:**

1. *Single-pipe architecture.* Build one `SGXNetFetcher` class that dispatches
   announcements to typed handlers by headline category code — do NOT replicate
   HK's split between DI scraper and CA scraper.
2. *Daily not monthly buybacks.* Schema needs `daily_returns[]` not
   `monthly_returns[]` for SG. Roll up to monthly view client-side.
3. *Director dealings come free.* Both substantial-shareholder and director
   changes share the SGXNET "Disclosure of Interest" category — distinguish via
   `role` field, do not build a separate scraper.
4. *No Connect flows.* `cap_market/{code}.json` schema must allow `null` for
   the `connect_flows[]` array.
5. *REITs and Business Trusts.* Add `security_type: "share" | "unit"` at the
   root of every JSON file. UI labels "shares" / "units" based on this field.
6. *Universe is small.* ~150-220 stocks means a full rescrape is < 1 hour;
   incremental is trivial.

**Stage 1 sign-off date:** _to be filled in when committed to the repo._

**Stage 1 open items carried into Stage 2:**

- Enumerate the exact `api.sgx.com` headline category codes for each filing
  type by inspecting a week of live browser network traffic. Pin in
  `config/sgx_categories.py`.
- Estimate 52-week backfill volume more precisely (~2,500-3,000 announcements
  with PDFs to parse is the working estimate).
- Confirm whether any third-party aggregator (e.g. SGinvestors.io) publishes
  structured Top-20 CDP data, which would short-cut annual-report PDF parsing.
- Decide whether free-float data needs a manual seed file for the top ~50 SG
  names (mirroring HK approach).
- Capture `api.sgx.com` Terms of Service language for Stage 7 review. The
  endpoint is undocumented as a public API; widely used in open-source code
  but a written ToS check belongs in the legal step.

#### Stage 2 — Data Exploration: PENDING

(To be completed. Use the Schema Mapping Template above. Build the three
section tables. Inspect at least 5 real filings per section.)

#### Stages 3–7: PENDING

---

### Japan (JP) — Planned

```
Status:        Not started
Universe:      Estimated ~500 stocks, > $1B USD mkt cap (higher
               threshold than HK/SG because JP universe is much larger)
Lookback:      52 weeks (incremental nightly)
Sections:      DI planned | CA planned | CM planned
```

Initial scoping notes carried forward from CIRCULAR_WORKFLOW_MAIN.md:

- DI source: EDINET REST API (`disclosure.edinet-api.go.jp`), docTypeCode
  "020" Large Shareholding Report. No VIEWSTATE. Parallelisable.
- CA source: TDnet (Tokyo Stock Exchange filings portal). PDF parsing via
  `pdfplumber` (same library as HK).
- CM source: TSE statistics archive — daily CSV.
- **Translation layer required.** Implement as Step 2a of every scraper
  pipeline. English text used directly when available in XBRL; Japanese
  fields translated and flagged `name_translated: true`. Normalise entity
  names against an alias list.

Stage 1 not yet started.

---

## Document Maintenance

```
+--------------------------------------------------------------------+
|  When to update this document                                       |
|                                                                     |
|  - A stage is completed for a market    -> tick the sub-checks      |
|  - A new market is being evaluated      -> add a "Market Entry"     |
|  - A scoping note proves wrong          -> correct it in place AND  |
|                                            note the correction      |
|  - markets.json status changes          -> mirror it here           |
|                                                                     |
|  Commit messages: "checklist: SG stage 2 schema mapping complete"   |
+--------------------------------------------------------------------+
```

Last review: _date when this document is next reviewed in full._
